package com.zmap.zmapapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZampappApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZampappApplication.class, args);
	}
}
